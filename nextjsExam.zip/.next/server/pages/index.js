/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "__barrel_optimize__?names=AppBar,Box,Button,Drawer,IconButton,List,ListItem,ListItemText,Toolbar,Typography!=!./node_modules/@mui/material/index.js":
/*!***********************************************************************************************************************************************************!*\
  !*** __barrel_optimize__?names=AppBar,Box,Button,Drawer,IconButton,List,ListItem,ListItemText,Toolbar,Typography!=!./node_modules/@mui/material/index.js ***!
  \***********************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   AppBar: () => (/* reexport safe */ _AppBar_index_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Box: () => (/* reexport safe */ _Box_index_js__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Button: () => (/* reexport safe */ _Button_index_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Drawer: () => (/* reexport safe */ _Drawer_index_js__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   IconButton: () => (/* reexport safe */ _IconButton_index_js__WEBPACK_IMPORTED_MODULE_4__[\"default\"]),\n/* harmony export */   List: () => (/* reexport safe */ _List_index_js__WEBPACK_IMPORTED_MODULE_5__[\"default\"]),\n/* harmony export */   ListItem: () => (/* reexport safe */ _ListItem_index_js__WEBPACK_IMPORTED_MODULE_6__[\"default\"]),\n/* harmony export */   ListItemText: () => (/* reexport safe */ _ListItemText_index_js__WEBPACK_IMPORTED_MODULE_7__[\"default\"]),\n/* harmony export */   Toolbar: () => (/* reexport safe */ _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_8__[\"default\"]),\n/* harmony export */   Typography: () => (/* reexport safe */ _Typography_index_js__WEBPACK_IMPORTED_MODULE_9__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _AppBar_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AppBar/index.js */ \"./node_modules/@mui/material/AppBar/index.js\");\n/* harmony import */ var _Box_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Box/index.js */ \"./node_modules/@mui/material/Box/index.js\");\n/* harmony import */ var _Button_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Button/index.js */ \"./node_modules/@mui/material/Button/index.js\");\n/* harmony import */ var _Drawer_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Drawer/index.js */ \"./node_modules/@mui/material/Drawer/index.js\");\n/* harmony import */ var _IconButton_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./IconButton/index.js */ \"./node_modules/@mui/material/IconButton/index.js\");\n/* harmony import */ var _List_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./List/index.js */ \"./node_modules/@mui/material/List/index.js\");\n/* harmony import */ var _ListItem_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ListItem/index.js */ \"./node_modules/@mui/material/ListItem/index.js\");\n/* harmony import */ var _ListItemText_index_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ListItemText/index.js */ \"./node_modules/@mui/material/ListItemText/index.js\");\n/* harmony import */ var _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Toolbar/index.js */ \"./node_modules/@mui/material/Toolbar/index.js\");\n/* harmony import */ var _Typography_index_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Typography/index.js */ \"./node_modules/@mui/material/Typography/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_AppBar_index_js__WEBPACK_IMPORTED_MODULE_0__, _Button_index_js__WEBPACK_IMPORTED_MODULE_2__, _Drawer_index_js__WEBPACK_IMPORTED_MODULE_3__, _IconButton_index_js__WEBPACK_IMPORTED_MODULE_4__, _List_index_js__WEBPACK_IMPORTED_MODULE_5__, _ListItem_index_js__WEBPACK_IMPORTED_MODULE_6__, _ListItemText_index_js__WEBPACK_IMPORTED_MODULE_7__, _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_8__, _Typography_index_js__WEBPACK_IMPORTED_MODULE_9__]);\n([_AppBar_index_js__WEBPACK_IMPORTED_MODULE_0__, _Button_index_js__WEBPACK_IMPORTED_MODULE_2__, _Drawer_index_js__WEBPACK_IMPORTED_MODULE_3__, _IconButton_index_js__WEBPACK_IMPORTED_MODULE_4__, _List_index_js__WEBPACK_IMPORTED_MODULE_5__, _ListItem_index_js__WEBPACK_IMPORTED_MODULE_6__, _ListItemText_index_js__WEBPACK_IMPORTED_MODULE_7__, _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_8__, _Typography_index_js__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\n\n\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1BcHBCYXIsQm94LEJ1dHRvbixEcmF3ZXIsSWNvbkJ1dHRvbixMaXN0LExpc3RJdGVtLExpc3RJdGVtVGV4dCxUb29sYmFyLFR5cG9ncmFwaHkhPSEuL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNxRDtBQUNOO0FBQ007QUFDQTtBQUNRO0FBQ1o7QUFDUTtBQUNRO0FBQ1YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWpzLWZpcnN0LWV4YW0vLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcz81ZDkwIl0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBBcHBCYXIgfSBmcm9tIFwiLi9BcHBCYXIvaW5kZXguanNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCb3ggfSBmcm9tIFwiLi9Cb3gvaW5kZXguanNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b24vaW5kZXguanNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBEcmF3ZXIgfSBmcm9tIFwiLi9EcmF3ZXIvaW5kZXguanNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBJY29uQnV0dG9uIH0gZnJvbSBcIi4vSWNvbkJ1dHRvbi9pbmRleC5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIExpc3QgfSBmcm9tIFwiLi9MaXN0L2luZGV4LmpzXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTGlzdEl0ZW0gfSBmcm9tIFwiLi9MaXN0SXRlbS9pbmRleC5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIExpc3RJdGVtVGV4dCB9IGZyb20gXCIuL0xpc3RJdGVtVGV4dC9pbmRleC5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIFRvb2xiYXIgfSBmcm9tIFwiLi9Ub29sYmFyL2luZGV4LmpzXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgVHlwb2dyYXBoeSB9IGZyb20gXCIuL1R5cG9ncmFwaHkvaW5kZXguanNcIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=AppBar,Box,Button,Drawer,IconButton,List,ListItem,ListItemText,Toolbar,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Box,Container,Grid,IconButton,Toolbar,Typography!=!./node_modules/@mui/material/index.js":
/*!**************************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Box,Container,Grid,IconButton,Toolbar,Typography!=!./node_modules/@mui/material/index.js ***!
  \**************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Box: () => (/* reexport safe */ _Box_index_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container_index_js__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Grid: () => (/* reexport safe */ _Grid_index_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   IconButton: () => (/* reexport safe */ _IconButton_index_js__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   Toolbar: () => (/* reexport safe */ _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_4__[\"default\"]),\n/* harmony export */   Typography: () => (/* reexport safe */ _Typography_index_js__WEBPACK_IMPORTED_MODULE_5__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Box_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Box/index.js */ \"./node_modules/@mui/material/Box/index.js\");\n/* harmony import */ var _Container_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container/index.js */ \"./node_modules/@mui/material/Container/index.js\");\n/* harmony import */ var _Grid_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Grid/index.js */ \"./node_modules/@mui/material/Grid/index.js\");\n/* harmony import */ var _IconButton_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./IconButton/index.js */ \"./node_modules/@mui/material/IconButton/index.js\");\n/* harmony import */ var _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Toolbar/index.js */ \"./node_modules/@mui/material/Toolbar/index.js\");\n/* harmony import */ var _Typography_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Typography/index.js */ \"./node_modules/@mui/material/Typography/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Grid_index_js__WEBPACK_IMPORTED_MODULE_2__, _IconButton_index_js__WEBPACK_IMPORTED_MODULE_3__, _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_4__, _Typography_index_js__WEBPACK_IMPORTED_MODULE_5__]);\n([_Grid_index_js__WEBPACK_IMPORTED_MODULE_2__, _IconButton_index_js__WEBPACK_IMPORTED_MODULE_3__, _Toolbar_index_js__WEBPACK_IMPORTED_MODULE_4__, _Typography_index_js__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1Cb3gsQ29udGFpbmVyLEdyaWQsSWNvbkJ1dHRvbixUb29sYmFyLFR5cG9ncmFwaHkhPSEuL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDK0M7QUFDWTtBQUNWO0FBQ1k7QUFDTiIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtanMtZmlyc3QtZXhhbS8uL25vZGVfbW9kdWxlcy9AbXVpL21hdGVyaWFsL2luZGV4LmpzPzJlMTMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJveCB9IGZyb20gXCIuL0JveC9pbmRleC5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENvbnRhaW5lciB9IGZyb20gXCIuL0NvbnRhaW5lci9pbmRleC5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEdyaWQgfSBmcm9tIFwiLi9HcmlkL2luZGV4LmpzXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgSWNvbkJ1dHRvbiB9IGZyb20gXCIuL0ljb25CdXR0b24vaW5kZXguanNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUb29sYmFyIH0gZnJvbSBcIi4vVG9vbGJhci9pbmRleC5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIFR5cG9ncmFwaHkgfSBmcm9tIFwiLi9UeXBvZ3JhcGh5L2luZGV4LmpzXCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Box,Container,Grid,IconButton,Toolbar,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js":
/*!***********************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Facebook: () => (/* reexport safe */ _Facebook_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Instagram: () => (/* reexport safe */ _Instagram_js__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   LinkedIn: () => (/* reexport safe */ _LinkedIn_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Twitter: () => (/* reexport safe */ _Twitter_js__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Facebook_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Facebook.js */ \"./node_modules/@mui/icons-material/esm/Facebook.js\");\n/* harmony import */ var _Instagram_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Instagram.js */ \"./node_modules/@mui/icons-material/esm/Instagram.js\");\n/* harmony import */ var _LinkedIn_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./LinkedIn.js */ \"./node_modules/@mui/icons-material/esm/LinkedIn.js\");\n/* harmony import */ var _Twitter_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Twitter.js */ \"./node_modules/@mui/icons-material/esm/Twitter.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1GYWNlYm9vayxJbnN0YWdyYW0sTGlua2VkSW4sVHdpdHRlciE9IS4vbm9kZV9tb2R1bGVzL0BtdWkvaWNvbnMtbWF0ZXJpYWwvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUNtRDtBQUNFO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWpzLWZpcnN0LWV4YW0vLi9ub2RlX21vZHVsZXMvQG11aS9pY29ucy1tYXRlcmlhbC9lc20vaW5kZXguanM/ZTlkNiJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRmFjZWJvb2sgfSBmcm9tIFwiLi9GYWNlYm9vay5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEluc3RhZ3JhbSB9IGZyb20gXCIuL0luc3RhZ3JhbS5qc1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIExpbmtlZEluIH0gZnJvbSBcIi4vTGlua2VkSW4uanNcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUd2l0dGVyIH0gZnJvbSBcIi4vVHdpdHRlci5qc1wiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js\n");

/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.tsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.tsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/future/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.tsx\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.tsx\");\n/* harmony import */ var _pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\index.tsx */ \"./pages/index.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__]);\nprivate_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"default\"));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"getStaticProps\");\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"getStaticPaths\");\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"getServerSideProps\");\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"config\");\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"reportWebVitals\");\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticProps\");\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticPaths\");\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticParams\");\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerProps\");\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerSideProps\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/index\",\n        pathname: \"/\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    components: {\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_index_tsx__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGcGFnZXMlNUNpbmRleC50c3gmYWJzb2x1dGVBcHBQYXRoPXByaXZhdGUtbmV4dC1wYWdlcyUyRl9hcHAmYWJzb2x1dGVEb2N1bWVudFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2RvY3VtZW50Jm1pZGRsZXdhcmVDb25maWdCYXNlNjQ9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ2hDO0FBQ0w7QUFDMUQ7QUFDb0Q7QUFDVjtBQUMxQztBQUMrQztBQUMvQztBQUNBLGlFQUFlLHdFQUFLLENBQUMsNkNBQVEsWUFBWSxFQUFDO0FBQzFDO0FBQ08sdUJBQXVCLHdFQUFLLENBQUMsNkNBQVE7QUFDckMsdUJBQXVCLHdFQUFLLENBQUMsNkNBQVE7QUFDckMsMkJBQTJCLHdFQUFLLENBQUMsNkNBQVE7QUFDekMsZUFBZSx3RUFBSyxDQUFDLDZDQUFRO0FBQzdCLHdCQUF3Qix3RUFBSyxDQUFDLDZDQUFRO0FBQzdDO0FBQ08sZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsaUNBQWlDLHdFQUFLLENBQUMsNkNBQVE7QUFDL0MsZ0NBQWdDLHdFQUFLLENBQUMsNkNBQVE7QUFDOUMsb0NBQW9DLHdFQUFLLENBQUMsNkNBQVE7QUFDekQ7QUFDTyx3QkFBd0IseUdBQWdCO0FBQy9DO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsV0FBVztBQUNYLGdCQUFnQjtBQUNoQixLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQsaUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWpzLWZpcnN0LWV4YW0vP2JhODEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFnZXNSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL3BhZ2VzL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IGhvaXN0IH0gZnJvbSBcIm5leHQvZGlzdC9idWlsZC90ZW1wbGF0ZXMvaGVscGVyc1wiO1xuLy8gSW1wb3J0IHRoZSBhcHAgYW5kIGRvY3VtZW50IG1vZHVsZXMuXG5pbXBvcnQgRG9jdW1lbnQgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fZG9jdW1lbnRcIjtcbmltcG9ydCBBcHAgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fYXBwXCI7XG4vLyBJbXBvcnQgdGhlIHVzZXJsYW5kIGNvZGUuXG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiLi9wYWdlc1xcXFxpbmRleC50c3hcIjtcbi8vIFJlLWV4cG9ydCB0aGUgY29tcG9uZW50IChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcImdldFN0YXRpY1Byb3BzXCIpO1xuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U3RhdGljUGF0aHNcIik7XG5leHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U2VydmVyU2lkZVByb3BzXCIpO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbmV4cG9ydCBjb25zdCByZXBvcnRXZWJWaXRhbHMgPSBob2lzdCh1c2VybGFuZCwgXCJyZXBvcnRXZWJWaXRhbHNcIik7XG4vLyBSZS1leHBvcnQgbGVnYWN5IG1ldGhvZHMuXG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U3RhdGljUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTdGF0aWNQcm9wc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1BhdGhzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhcmFtcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1BhcmFtc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTZXJ2ZXJQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFNlcnZlclByb3BzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wc1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTLFxuICAgICAgICBwYWdlOiBcIi9pbmRleFwiLFxuICAgICAgICBwYXRobmFtZTogXCIvXCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogXCJcIixcbiAgICAgICAgZmlsZW5hbWU6IFwiXCJcbiAgICB9LFxuICAgIGNvbXBvbmVudHM6IHtcbiAgICAgICAgQXBwLFxuICAgICAgICBEb2N1bWVudFxuICAgIH0sXG4gICAgdXNlcmxhbmRcbn0pO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYWdlcy5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.tsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./layout/footer/index.tsx":
/*!*********************************!*\
  !*** ./layout/footer/index.tsx ***!
  \*********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Box,Container,Grid,IconButton,Toolbar,Typography!=!@mui/material */ \"__barrel_optimize__?names=Box,Container,Grid,IconButton,Toolbar,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!@mui/icons-material */ \"__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__]);\n_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nvar footerLinks = [\n    {\n        id: 1,\n        title: \"Home\",\n        link: \"/home\"\n    },\n    {\n        id: 2,\n        title: \"About\",\n        link: \"/about\"\n    },\n    {\n        id: 3,\n        title: \"Products\",\n        link: \"/productlist\"\n    },\n    {\n        id: 4,\n        title: \"Create\",\n        link: \"/create\"\n    }\n];\nconst Footer = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {\n            component: \"footer\",\n            // position={'static'}\n            sx: {\n                background: \"linear-gradient(to right, #5b636a, #5e5b6a)\",\n                color: \"white\",\n                paddingTop: 2,\n                paddingBottom: 2\n            },\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {\n                maxWidth: \"md\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                        container: true,\n                        spacing: 4,\n                        alignItems: \"center\",\n                        justifyContent: \"space-between\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                                item: true,\n                                xs: 12,\n                                md: 3,\n                                justifyContent: \"center\",\n                                className: \"footer-links\",\n                                children: footerLinks.map((link)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                        href: link.link,\n                                        color: \"inherit\",\n                                        style: {\n                                            marginRight: 3,\n                                            textDecoration: \"none\"\n                                        },\n                                        children: link.title\n                                    }, link.id, false, {\n                                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                        lineNumber: 47,\n                                        columnNumber: 15\n                                    }, undefined))\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                lineNumber: 45,\n                                columnNumber: 11\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                                item: true,\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                        href: \"https://facebook.com\",\n                                        target: \"_blank\",\n                                        color: \"inherit\",\n                                        sx: {\n                                            \"&:hover\": {\n                                                color: \"#1877f2\"\n                                            }\n                                        },\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Facebook, {}, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                            lineNumber: 56,\n                                            columnNumber: 15\n                                        }, undefined)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                        lineNumber: 55,\n                                        columnNumber: 13\n                                    }, undefined),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                        href: \"https://twitter.com\",\n                                        target: \"_blank\",\n                                        color: \"inherit\",\n                                        sx: {\n                                            \"&:hover\": {\n                                                color: \"#1da1f2\"\n                                            }\n                                        },\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Twitter, {}, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                            lineNumber: 59,\n                                            columnNumber: 15\n                                        }, undefined)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                        lineNumber: 58,\n                                        columnNumber: 13\n                                    }, undefined),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                        href: \"https://instagram.com\",\n                                        target: \"_blank\",\n                                        color: \"inherit\",\n                                        sx: {\n                                            \"&:hover\": {\n                                                color: \"#e1306c\"\n                                            }\n                                        },\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Instagram, {}, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                            lineNumber: 62,\n                                            columnNumber: 15\n                                        }, undefined)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                        lineNumber: 61,\n                                        columnNumber: 13\n                                    }, undefined),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                        href: \"https://linkedin.com\",\n                                        target: \"_blank\",\n                                        color: \"inherit\",\n                                        sx: {\n                                            \"&:hover\": {\n                                                color: \"#0077b5\"\n                                            }\n                                        },\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.LinkedIn, {}, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                            lineNumber: 65,\n                                            columnNumber: 15\n                                        }, undefined)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                        lineNumber: 64,\n                                        columnNumber: 13\n                                    }, undefined)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                lineNumber: 54,\n                                columnNumber: 11\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                                item: true,\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                    href: \"/terms\",\n                                    color: \"inherit\",\n                                    children: \"Terms & Conditions\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                    lineNumber: 71,\n                                    columnNumber: 13\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                                lineNumber: 70,\n                                columnNumber: 11\n                            }, undefined)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                        lineNumber: 43,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Toolbar, {\n                        sx: {\n                            justifyContent: \"center\",\n                            borderTop: \"1px solid rgba(255, 255, 255, 0.2)\",\n                            paddingTop: 2\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                            variant: \"body2\",\n                            color: \"inherit\",\n                            children: \"\\xa9 2024 Your Company. All rights reserved.\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                            lineNumber: 79,\n                            columnNumber: 11\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                        lineNumber: 78,\n                        columnNumber: 9\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n                lineNumber: 42,\n                columnNumber: 7\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\footer\\\\index.tsx\",\n            lineNumber: 32,\n            columnNumber: 5\n        }, undefined)\n    }, void 0, false);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvZm9vdGVyL2luZGV4LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQXFGO0FBQ1I7QUFDcEQ7QUFDSTtBQUc3QixJQUFJWSxjQUFjO0lBQ2Q7UUFDRUMsSUFBSTtRQUNKQyxPQUFPO1FBQ1BDLE1BQU07SUFDUjtJQUNBO1FBQ0VGLElBQUk7UUFDSkMsT0FBTztRQUNQQyxNQUFNO0lBQ1I7SUFDQTtRQUNFRixJQUFJO1FBQ0pDLE9BQU87UUFDUEMsTUFBTTtJQUNSO0lBQ0E7UUFDRUYsSUFBSTtRQUNKQyxPQUFPO1FBQ1BDLE1BQU07SUFDUjtDQUNEO0FBQ0gsTUFBTUMsU0FBb0I7SUFDeEIscUJBQ0U7a0JBQ0EsNEVBQUNoQixxSEFBR0E7WUFDRmlCLFdBQVU7WUFDVixzQkFBc0I7WUFDdEJDLElBQUk7Z0JBQ0ZDLFlBQVk7Z0JBQ1pDLE9BQU87Z0JBQ1BDLFlBQVk7Z0JBQ1pDLGVBQWU7WUFDakI7c0JBRUEsNEVBQUNyQiwySEFBU0E7Z0JBQUNzQixVQUFTOztrQ0FDbEIsOERBQUNyQixzSEFBSUE7d0JBQUNzQixTQUFTO3dCQUFDQyxTQUFTO3dCQUFHQyxZQUFXO3dCQUFTQyxnQkFBZTs7MENBRTdELDhEQUFDekIsc0hBQUlBO2dDQUFDMEIsSUFBSTtnQ0FBQ0MsSUFBSTtnQ0FBSUMsSUFBSTtnQ0FBR0gsZ0JBQWU7Z0NBQVNJLFdBQVU7MENBQ3pEbkIsWUFBWW9CLEdBQUcsQ0FBQyxDQUFDakIscUJBQ2hCLDhEQUFDSixrREFBSUE7d0NBQWVzQixNQUFNbEIsS0FBS0EsSUFBSTt3Q0FBRUssT0FBTTt3Q0FBVWMsT0FBTzs0Q0FBRUMsYUFBYTs0Q0FBRUMsZ0JBQWdCO3dDQUFPO2tEQUNqR3JCLEtBQUtELEtBQUs7dUNBREZDLEtBQUtGLEVBQUU7Ozs7Ozs7Ozs7MENBT3RCLDhEQUFDWCxzSEFBSUE7Z0NBQUMwQixJQUFJOztrREFDUiw4REFBQ3pCLDRIQUFVQTt3Q0FBQzhCLE1BQUs7d0NBQXVCSSxRQUFPO3dDQUFTakIsT0FBTTt3Q0FBVUYsSUFBSTs0Q0FBRSxXQUFXO2dEQUFFRSxPQUFPOzRDQUFVO3dDQUFFO2tEQUM1Ryw0RUFBQ2QsbUhBQVFBOzs7Ozs7Ozs7O2tEQUVYLDhEQUFDSCw0SEFBVUE7d0NBQUM4QixNQUFLO3dDQUFzQkksUUFBTzt3Q0FBU2pCLE9BQU07d0NBQVVGLElBQUk7NENBQUUsV0FBVztnREFBRUUsT0FBTzs0Q0FBVTt3Q0FBRTtrREFDM0csNEVBQUNiLGtIQUFPQTs7Ozs7Ozs7OztrREFFViw4REFBQ0osNEhBQVVBO3dDQUFDOEIsTUFBSzt3Q0FBd0JJLFFBQU87d0NBQVNqQixPQUFNO3dDQUFVRixJQUFJOzRDQUFFLFdBQVc7Z0RBQUVFLE9BQU87NENBQVU7d0NBQUU7a0RBQzdHLDRFQUFDWixvSEFBU0E7Ozs7Ozs7Ozs7a0RBRVosOERBQUNMLDRIQUFVQTt3Q0FBQzhCLE1BQUs7d0NBQXVCSSxRQUFPO3dDQUFTakIsT0FBTTt3Q0FBVUYsSUFBSTs0Q0FBRSxXQUFXO2dEQUFFRSxPQUFPOzRDQUFVO3dDQUFFO2tEQUM1Ryw0RUFBQ1gsbUhBQVFBOzs7Ozs7Ozs7Ozs7Ozs7OzBDQUtiLDhEQUFDUCxzSEFBSUE7Z0NBQUMwQixJQUFJOzBDQUNSLDRFQUFDakIsa0RBQUlBO29DQUFDc0IsTUFBSztvQ0FBU2IsT0FBTTs4Q0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7a0NBT3hDLDhEQUFDaEIseUhBQU9BO3dCQUFDYyxJQUFJOzRCQUFFUyxnQkFBZ0I7NEJBQVVXLFdBQVc7NEJBQXNDakIsWUFBWTt3QkFBRTtrQ0FDdEcsNEVBQUNoQiw0SEFBVUE7NEJBQUNrQyxTQUFROzRCQUFRbkIsT0FBTTtzQ0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFRdEQ7QUFFQSxpRUFBZUosTUFBTUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtanMtZmlyc3QtZXhhbS8uL2xheW91dC9mb290ZXIvaW5kZXgudHN4PzE4ZDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94LCBDb250YWluZXIsIEdyaWQsIEljb25CdXR0b24sIFRvb2xiYXIsIFR5cG9ncmFwaHkgfSBmcm9tICdAbXVpL21hdGVyaWFsJ1xyXG5pbXBvcnQgeyBGYWNlYm9vaywgVHdpdHRlciwgSW5zdGFncmFtLCBMaW5rZWRJbiB9IGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcblxyXG5cclxudmFyIGZvb3RlckxpbmtzID0gW1xyXG4gICAge1xyXG4gICAgICBpZDogMSxcclxuICAgICAgdGl0bGU6IFwiSG9tZVwiLFxyXG4gICAgICBsaW5rOiBcIi9ob21lXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogXCJBYm91dFwiLFxyXG4gICAgICBsaW5rOiBcIi9hYm91dFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogMyxcclxuICAgICAgdGl0bGU6IFwiUHJvZHVjdHNcIixcclxuICAgICAgbGluazogXCIvcHJvZHVjdGxpc3RcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IDQsXHJcbiAgICAgIHRpdGxlOiBcIkNyZWF0ZVwiLFxyXG4gICAgICBsaW5rOiBcIi9jcmVhdGVcIlxyXG4gICAgfVxyXG4gIF1cclxuY29uc3QgRm9vdGVyIDogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICA8Qm94XHJcbiAgICAgIGNvbXBvbmVudD1cImZvb3RlclwiXHJcbiAgICAgIC8vIHBvc2l0aW9uPXsnc3RhdGljJ31cclxuICAgICAgc3g9e3tcclxuICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNWI2MzZhLCAjNWU1YjZhKScsXHJcbiAgICAgICAgY29sb3I6ICd3aGl0ZScsXHJcbiAgICAgICAgcGFkZGluZ1RvcDogMixcclxuICAgICAgICBwYWRkaW5nQm90dG9tOiAyLFxyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwibWRcIj5cclxuICAgICAgICA8R3JpZCBjb250YWluZXIgc3BhY2luZz17NH0gYWxpZ25JdGVtcz1cImNlbnRlclwiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiPlxyXG4gICAgICAgICAgey8qIFBhZ2VzIExpbmtzICovfVxyXG4gICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXszfSBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiIGNsYXNzTmFtZT0nZm9vdGVyLWxpbmtzJz5cclxuICAgICAgICAgICAge2Zvb3RlckxpbmtzLm1hcCgobGluaykgPT4gKFxyXG4gICAgICAgICAgICAgIDxMaW5rIGtleT17bGluay5pZH0gaHJlZj17bGluay5saW5rfSBjb2xvcj1cImluaGVyaXRcIiBzdHlsZT17eyBtYXJnaW5SaWdodDogMyx0ZXh0RGVjb3JhdGlvbjogJ25vbmUnIH19PlxyXG4gICAgICAgICAgICAgICAge2xpbmsudGl0bGV9XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvR3JpZD5cclxuXHJcbiAgICAgICAgICB7LyogU29jaWFsIE1lZGlhIEljb25zICovfVxyXG4gICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgPEljb25CdXR0b24gaHJlZj1cImh0dHBzOi8vZmFjZWJvb2suY29tXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY29sb3I9XCJpbmhlcml0XCIgc3g9e3sgJyY6aG92ZXInOiB7IGNvbG9yOiAnIzE4NzdmMicgfSB9fT5cclxuICAgICAgICAgICAgICA8RmFjZWJvb2sgLz5cclxuICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICA8SWNvbkJ1dHRvbiBocmVmPVwiaHR0cHM6Ly90d2l0dGVyLmNvbVwiIHRhcmdldD1cIl9ibGFua1wiIGNvbG9yPVwiaW5oZXJpdFwiIHN4PXt7ICcmOmhvdmVyJzogeyBjb2xvcjogJyMxZGExZjInIH0gfX0+XHJcbiAgICAgICAgICAgICAgPFR3aXR0ZXIgLz5cclxuICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICA8SWNvbkJ1dHRvbiBocmVmPVwiaHR0cHM6Ly9pbnN0YWdyYW0uY29tXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY29sb3I9XCJpbmhlcml0XCIgc3g9e3sgJyY6aG92ZXInOiB7IGNvbG9yOiAnI2UxMzA2YycgfSB9fT5cclxuICAgICAgICAgICAgICA8SW5zdGFncmFtIC8+XHJcbiAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgPEljb25CdXR0b24gaHJlZj1cImh0dHBzOi8vbGlua2VkaW4uY29tXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY29sb3I9XCJpbmhlcml0XCIgc3g9e3sgJyY6aG92ZXInOiB7IGNvbG9yOiAnIzAwNzdiNScgfSB9fT5cclxuICAgICAgICAgICAgICA8TGlua2VkSW4gLz5cclxuICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG5cclxuICAgICAgICAgIHsvKiBUZXJtcyBhbmQgQ29uZGl0aW9ucyAqL31cclxuICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvdGVybXNcIiBjb2xvcj1cImluaGVyaXRcIj5cclxuICAgICAgICAgICAgICBUZXJtcyAmIENvbmRpdGlvbnNcclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuXHJcbiAgICAgICAgey8qIENvcHlyaWdodCBTZWN0aW9uICovfVxyXG4gICAgICAgIDxUb29sYmFyIHN4PXt7IGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgYm9yZGVyVG9wOiAnMXB4IHNvbGlkIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKScsIHBhZGRpbmdUb3A6IDIgfX0+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cImluaGVyaXRcIj5cclxuICAgICAgICAgICAgwqkgMjAyNCBZb3VyIENvbXBhbnkuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPC9Ub29sYmFyPlxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgIDwvQm94PlxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGb290ZXIiXSwibmFtZXMiOlsiQm94IiwiQ29udGFpbmVyIiwiR3JpZCIsIkljb25CdXR0b24iLCJUb29sYmFyIiwiVHlwb2dyYXBoeSIsIkZhY2Vib29rIiwiVHdpdHRlciIsIkluc3RhZ3JhbSIsIkxpbmtlZEluIiwiUmVhY3QiLCJMaW5rIiwiZm9vdGVyTGlua3MiLCJpZCIsInRpdGxlIiwibGluayIsIkZvb3RlciIsImNvbXBvbmVudCIsInN4IiwiYmFja2dyb3VuZCIsImNvbG9yIiwicGFkZGluZ1RvcCIsInBhZGRpbmdCb3R0b20iLCJtYXhXaWR0aCIsImNvbnRhaW5lciIsInNwYWNpbmciLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJpdGVtIiwieHMiLCJtZCIsImNsYXNzTmFtZSIsIm1hcCIsImhyZWYiLCJzdHlsZSIsIm1hcmdpblJpZ2h0IiwidGV4dERlY29yYXRpb24iLCJ0YXJnZXQiLCJib3JkZXJUb3AiLCJ2YXJpYW50Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./layout/footer/index.tsx\n");

/***/ }),

/***/ "./layout/header/index.tsx":
/*!*********************************!*\
  !*** ./layout/header/index.tsx ***!
  \*********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! __barrel_optimize__?names=AppBar,Box,Button,Drawer,IconButton,List,ListItem,ListItemText,Toolbar,Typography!=!@mui/material */ \"__barrel_optimize__?names=AppBar,Box,Button,Drawer,IconButton,List,ListItem,ListItemText,Toolbar,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _mui_icons_material_LocalLibrary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/LocalLibrary */ \"@mui/icons-material/LocalLibrary\");\n/* harmony import */ var _mui_icons_material_LocalLibrary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocalLibrary__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/Menu */ \"@mui/icons-material/Menu\");\n/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__]);\n_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n/* __next_internal_client_entry_do_not_use__ default auto */ \n\n\n\n\n\nconst Header = ()=>{\n    const [isDrawerOpen, setIsDrawerOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const toggleDrawer = (open)=>(event)=>{\n            if (event.type === \"keydown\" && (event.key === \"Tab\" || event.key === \"Shift\")) {\n                return;\n            }\n            setIsDrawerOpen(open);\n        };\n    const drawerList = /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {\n        sx: {\n            width: \"100vw\",\n            maxWidth: \"100vw\",\n            paddingTop: \"10px\",\n            paddingBottom: \"10px\",\n            boxSizing: \"border-box\",\n            overflowX: \"hidden\"\n        },\n        role: \"presentation\",\n        onClick: toggleDrawer(false),\n        onKeyDown: toggleDrawer(false),\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.List, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItem, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                        href: \"/\",\n                        style: {\n                            textDecoration: \"none\",\n                            color: \"inherit\"\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItemText, {\n                            primary: \"Home\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 50,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 49,\n                        columnNumber: 11\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                    lineNumber: 48,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItem, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                        href: \"/about\",\n                        style: {\n                            textDecoration: \"none\",\n                            color: \"inherit\"\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItemText, {\n                            primary: \"About\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 58,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 54,\n                        columnNumber: 11\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                    lineNumber: 53,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItem, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                        href: \"/cms/all-products\",\n                        style: {\n                            textDecoration: \"none\",\n                            color: \"inherit\"\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItemText, {\n                            primary: \"Products\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 66,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 62,\n                        columnNumber: 11\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                    lineNumber: 61,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItem, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                        href: \"/contact\",\n                        style: {\n                            textDecoration: \"none\",\n                            color: \"inherit\"\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItemText, {\n                            primary: \"Contact\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 74,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 70,\n                        columnNumber: 11\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                    lineNumber: 69,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItem, {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                        href: \"/auth/login\",\n                        style: {\n                            textDecoration: \"none\",\n                            color: \"inherit\"\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.ListItemText, {\n                            primary: \"LogIn\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 79,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 78,\n                        columnNumber: 11\n                    }, undefined)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                    lineNumber: 77,\n                    columnNumber: 9\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n            lineNumber: 47,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n        lineNumber: 34,\n        columnNumber: 5\n    }, undefined);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.AppBar, {\n            position: \"static\",\n            style: {\n                backgroundColor: \"#5b636a\"\n            },\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Toolbar, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {\n                        size: \"large\",\n                        edge: \"start\",\n                        color: \"inherit\",\n                        \"aria-label\": \"logo\",\n                        sx: {\n                            display: {\n                                xs: \"none\",\n                                md: \"flex\"\n                            }\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_LocalLibrary__WEBPACK_IMPORTED_MODULE_2___default()), {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 97,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 90,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {\n                        variant: \"h6\",\n                        component: \"div\",\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                xs: \"none\",\n                                md: \"flex\"\n                            }\n                        },\n                        children: \"FrontEnd PathSala\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 99,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {\n                        sx: {\n                            display: {\n                                xs: \"none\",\n                                md: \"flex\"\n                            }\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                href: \"/\",\n                                style: {\n                                    textDecoration: \"none\",\n                                    color: \"inherit\"\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                    color: \"inherit\",\n                                    children: \"Home\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                    lineNumber: 111,\n                                    columnNumber: 15\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 107,\n                                columnNumber: 13\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                href: \"/about\",\n                                style: {\n                                    textDecoration: \"none\",\n                                    color: \"inherit\"\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                    color: \"inherit\",\n                                    children: \"About\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                    lineNumber: 117,\n                                    columnNumber: 15\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 113,\n                                columnNumber: 13\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                href: \"/cms/all-products\",\n                                style: {\n                                    textDecoration: \"none\",\n                                    color: \"inherit\"\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                    color: \"inherit\",\n                                    children: \"Products\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                    lineNumber: 123,\n                                    columnNumber: 15\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 119,\n                                columnNumber: 13\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                href: \"/contact\",\n                                style: {\n                                    textDecoration: \"none\",\n                                    color: \"inherit\"\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                    color: \"inherit\",\n                                    children: \"Contact\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                    lineNumber: 129,\n                                    columnNumber: 15\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 125,\n                                columnNumber: 13\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                href: \"/auth/login\",\n                                style: {\n                                    textDecoration: \"none\",\n                                    color: \"inherit\"\n                                },\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {\n                                    color: \"inherit\",\n                                    children: \"LogIn\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                    lineNumber: 132,\n                                    columnNumber: 15\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 131,\n                                columnNumber: 13\n                            }, undefined)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 106,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {\n                        sx: {\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            }\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {\n                                size: \"large\",\n                                edge: \"start\",\n                                color: \"inherit\",\n                                onClick: toggleDrawer(true),\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_3___default()), {}, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                    lineNumber: 142,\n                                    columnNumber: 15\n                                }, undefined)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 136,\n                                columnNumber: 13\n                            }, undefined),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Drawer, {\n                                anchor: \"top\",\n                                open: isDrawerOpen,\n                                onClose: toggleDrawer(false),\n                                PaperProps: {\n                                    sx: {\n                                        width: \"100vw\",\n                                        margin: 0,\n                                        padding: 0,\n                                        overflowX: \"hidden\"\n                                    }\n                                },\n                                children: drawerList\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                                lineNumber: 144,\n                                columnNumber: 13\n                            }, undefined)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 135,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {\n                        size: \"large\",\n                        edge: \"start\",\n                        color: \"inherit\",\n                        \"aria-label\": \"logo\",\n                        sx: {\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            }\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_LocalLibrary__WEBPACK_IMPORTED_MODULE_2___default()), {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                            lineNumber: 167,\n                            columnNumber: 13\n                        }, undefined)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 160,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_AppBar_Box_Button_Drawer_IconButton_List_ListItem_ListItemText_Toolbar_Typography_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {\n                        variant: \"h6\",\n                        component: \"div\",\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            }\n                        },\n                        children: \"FrontEnd PathSala\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                        lineNumber: 169,\n                        columnNumber: 11\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n                lineNumber: 89,\n                columnNumber: 9\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n            lineNumber: 88,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\header\\\\index.tsx\",\n        lineNumber: 87,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvaGVhZGVyL2luZGV4LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ3dDO0FBWWpCO0FBQ3lDO0FBQ2hCO0FBQ25CO0FBRzdCLE1BQU1lLFNBQVM7SUFDYixNQUFNLENBQUNDLGNBQWNDLGdCQUFnQixHQUFHaEIsK0NBQVFBLENBQUM7SUFFakQsTUFBTWlCLGVBQWUsQ0FBQ0MsT0FBa0IsQ0FBQ0M7WUFDdkMsSUFDRUEsTUFBTUMsSUFBSSxLQUFLLGFBQ2QsT0FBK0JDLEdBQUcsS0FBSyxTQUFTLE1BQStCQSxHQUFHLEtBQUssT0FBTSxHQUM5RjtnQkFDQTtZQUNGO1lBQ0FMLGdCQUFnQkU7UUFDbEI7SUFFQSxNQUFNSSwyQkFDSiw4REFBQ3BCLHNKQUFHQTtRQUNGcUIsSUFBSTtZQUNGQyxPQUFPO1lBQ1BDLFVBQVU7WUFDVkMsWUFBWTtZQUNaQyxlQUFlO1lBQ2ZDLFdBQVc7WUFDWEMsV0FBVztRQUNiO1FBQ0FDLE1BQUs7UUFDTEMsU0FBU2QsYUFBYTtRQUN0QmUsV0FBV2YsYUFBYTtrQkFFeEIsNEVBQUNULHVKQUFJQTs7OEJBQ0gsOERBQUNDLDJKQUFRQTs4QkFDUCw0RUFBQ0ksa0RBQUlBO3dCQUFDb0IsTUFBSzt3QkFBSUMsT0FBTzs0QkFBRUMsZ0JBQWdCOzRCQUFRQyxPQUFPO3dCQUFVO2tDQUMvRCw0RUFBQzFCLCtKQUFZQTs0QkFBQzJCLFNBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBRzFCLDhEQUFDNUIsMkpBQVFBOzhCQUNQLDRFQUFDSSxrREFBSUE7d0JBQ0hvQixNQUFLO3dCQUNMQyxPQUFPOzRCQUFFQyxnQkFBZ0I7NEJBQVFDLE9BQU87d0JBQVU7a0NBRWxELDRFQUFDMUIsK0pBQVlBOzRCQUFDMkIsU0FBUTs7Ozs7Ozs7Ozs7Ozs7Ozs4QkFHMUIsOERBQUM1QiwySkFBUUE7OEJBQ1AsNEVBQUNJLGtEQUFJQTt3QkFDSG9CLE1BQUs7d0JBQ0xDLE9BQU87NEJBQUVDLGdCQUFnQjs0QkFBUUMsT0FBTzt3QkFBVTtrQ0FFbEQsNEVBQUMxQiwrSkFBWUE7NEJBQUMyQixTQUFROzs7Ozs7Ozs7Ozs7Ozs7OzhCQUcxQiw4REFBQzVCLDJKQUFRQTs4QkFDUCw0RUFBQ0ksa0RBQUlBO3dCQUNIb0IsTUFBSzt3QkFDTEMsT0FBTzs0QkFBRUMsZ0JBQWdCOzRCQUFRQyxPQUFPO3dCQUFVO2tDQUVsRCw0RUFBQzFCLCtKQUFZQTs0QkFBQzJCLFNBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBRzFCLDhEQUFDNUIsMkpBQVFBOzhCQUNQLDRFQUFDSSxrREFBSUE7d0JBQUNvQixNQUFLO3dCQUFjQyxPQUFPOzRCQUFFQyxnQkFBZ0I7NEJBQVFDLE9BQU87d0JBQVU7a0NBQ3pFLDRFQUFDMUIsK0pBQVlBOzRCQUFDMkIsU0FBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBT2hDLHFCQUNFLDhEQUFDQztrQkFDQyw0RUFBQ3JDLHlKQUFNQTtZQUFDc0MsVUFBUztZQUFTTCxPQUFPO2dCQUFFTSxpQkFBaUI7WUFBVTtzQkFDNUQsNEVBQUNuQywwSkFBT0E7O2tDQUNOLDhEQUFDRCw2SkFBVUE7d0JBQ1RxQyxNQUFLO3dCQUNMQyxNQUFLO3dCQUNMTixPQUFNO3dCQUNOTyxjQUFXO3dCQUNYcEIsSUFBSTs0QkFBRXFCLFNBQVM7Z0NBQUVDLElBQUk7Z0NBQVFDLElBQUk7NEJBQU87d0JBQUU7a0NBRTFDLDRFQUFDbkMseUVBQWdCQTs7Ozs7Ozs7OztrQ0FFbkIsOERBQUNMLDZKQUFVQTt3QkFDVHlDLFNBQVE7d0JBQ1JDLFdBQVU7d0JBQ1Z6QixJQUFJOzRCQUFFMEIsVUFBVTs0QkFBR0wsU0FBUztnQ0FBRUMsSUFBSTtnQ0FBUUMsSUFBSTs0QkFBTzt3QkFBRTtrQ0FDeEQ7Ozs7OztrQ0FHRCw4REFBQzVDLHNKQUFHQTt3QkFBQ3FCLElBQUk7NEJBQUVxQixTQUFTO2dDQUFFQyxJQUFJO2dDQUFRQyxJQUFJOzRCQUFPO3dCQUFFOzswQ0FDN0MsOERBQUNqQyxrREFBSUE7Z0NBQ0hvQixNQUFLO2dDQUNMQyxPQUFPO29DQUFFQyxnQkFBZ0I7b0NBQVFDLE9BQU87Z0NBQVU7MENBRWxELDRFQUFDakMseUpBQU1BO29DQUFDaUMsT0FBTTs4Q0FBVTs7Ozs7Ozs7Ozs7MENBRTFCLDhEQUFDdkIsa0RBQUlBO2dDQUNIb0IsTUFBSztnQ0FDTEMsT0FBTztvQ0FBRUMsZ0JBQWdCO29DQUFRQyxPQUFPO2dDQUFVOzBDQUVsRCw0RUFBQ2pDLHlKQUFNQTtvQ0FBQ2lDLE9BQU07OENBQVU7Ozs7Ozs7Ozs7OzBDQUUxQiw4REFBQ3ZCLGtEQUFJQTtnQ0FDSG9CLE1BQUs7Z0NBQ0xDLE9BQU87b0NBQUVDLGdCQUFnQjtvQ0FBUUMsT0FBTztnQ0FBVTswQ0FFbEQsNEVBQUNqQyx5SkFBTUE7b0NBQUNpQyxPQUFNOzhDQUFVOzs7Ozs7Ozs7OzswQ0FFMUIsOERBQUN2QixrREFBSUE7Z0NBQ0hvQixNQUFLO2dDQUNMQyxPQUFPO29DQUFFQyxnQkFBZ0I7b0NBQVFDLE9BQU87Z0NBQVU7MENBRWxELDRFQUFDakMseUpBQU1BO29DQUFDaUMsT0FBTTs4Q0FBVTs7Ozs7Ozs7Ozs7MENBRTFCLDhEQUFDdkIsa0RBQUlBO2dDQUFDb0IsTUFBSztnQ0FBY0MsT0FBTztvQ0FBRUMsZ0JBQWdCO29DQUFRQyxPQUFPO2dDQUFVOzBDQUN6RSw0RUFBQ2pDLHlKQUFNQTtvQ0FBQ2lDLE9BQU07OENBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7O2tDQUc1Qiw4REFBQ2xDLHNKQUFHQTt3QkFBQ3FCLElBQUk7NEJBQUVxQixTQUFTO2dDQUFFQyxJQUFJO2dDQUFRQyxJQUFJOzRCQUFPO3dCQUFFOzswQ0FDN0MsOERBQUMxQyw2SkFBVUE7Z0NBQ1RxQyxNQUFLO2dDQUNMQyxNQUFLO2dDQUNMTixPQUFNO2dDQUNOTCxTQUFTZCxhQUFhOzBDQUV0Qiw0RUFBQ0wsaUVBQVFBOzs7Ozs7Ozs7OzBDQUVYLDhEQUFDTCx5SkFBTUE7Z0NBQ0wyQyxRQUFPO2dDQUNQaEMsTUFBTUg7Z0NBQ05vQyxTQUFTbEMsYUFBYTtnQ0FDdEJtQyxZQUFZO29DQUNWN0IsSUFBSTt3Q0FDRkMsT0FBTzt3Q0FDUDZCLFFBQVE7d0NBQ1JDLFNBQVM7d0NBQ1R6QixXQUFXO29DQUNiO2dDQUNGOzBDQUVDUDs7Ozs7Ozs7Ozs7O2tDQUdMLDhEQUFDbEIsNkpBQVVBO3dCQUNUcUMsTUFBSzt3QkFDTEMsTUFBSzt3QkFDTE4sT0FBTTt3QkFDTk8sY0FBVzt3QkFDWHBCLElBQUk7NEJBQUVxQixTQUFTO2dDQUFFQyxJQUFJO2dDQUFRQyxJQUFJOzRCQUFPO3dCQUFFO2tDQUUxQyw0RUFBQ25DLHlFQUFnQkE7Ozs7Ozs7Ozs7a0NBRW5CLDhEQUFDTCw2SkFBVUE7d0JBQ1R5QyxTQUFRO3dCQUNSQyxXQUFVO3dCQUNWekIsSUFBSTs0QkFBRTBCLFVBQVU7NEJBQUdMLFNBQVM7Z0NBQUVDLElBQUk7Z0NBQVFDLElBQUk7NEJBQU87d0JBQUU7a0NBQ3hEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT1g7QUFFQSxpRUFBZWhDLE1BQU1BLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWpzLWZpcnN0LWV4YW0vLi9sYXlvdXQvaGVhZGVyL2luZGV4LnRzeD84ZDJjIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBBcHBCYXIsXHJcbiAgQm94LFxyXG4gIEJ1dHRvbixcclxuICBJY29uQnV0dG9uLFxyXG4gIFRvb2xiYXIsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBEcmF3ZXIsXHJcbiAgTGlzdCxcclxuICBMaXN0SXRlbSxcclxuICBMaXN0SXRlbVRleHRcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgTG9jYWxMaWJyYXJ5SWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9Mb2NhbExpYnJhcnlcIjtcclxuaW1wb3J0IE1lbnVJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL01lbnVcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5cclxuXHJcbmNvbnN0IEhlYWRlciA9ICgpID0+IHtcclxuICBjb25zdCBbaXNEcmF3ZXJPcGVuLCBzZXRJc0RyYXdlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCB0b2dnbGVEcmF3ZXIgPSAob3BlbjogYm9vbGVhbikgPT4gKGV2ZW50OiBSZWFjdC5LZXlib2FyZEV2ZW50IHwgUmVhY3QuTW91c2VFdmVudCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBldmVudC50eXBlID09PSBcImtleWRvd25cIiAmJlxyXG4gICAgICAoKGV2ZW50IGFzIFJlYWN0LktleWJvYXJkRXZlbnQpLmtleSA9PT0gXCJUYWJcIiB8fCAoZXZlbnQgYXMgUmVhY3QuS2V5Ym9hcmRFdmVudCkua2V5ID09PSBcIlNoaWZ0XCIpXHJcbiAgICApIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgc2V0SXNEcmF3ZXJPcGVuKG9wZW4pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGRyYXdlckxpc3QgPSAoXHJcbiAgICA8Qm94XHJcbiAgICAgIHN4PXt7XHJcbiAgICAgICAgd2lkdGg6IFwiMTAwdndcIixcclxuICAgICAgICBtYXhXaWR0aDogXCIxMDB2d1wiLFxyXG4gICAgICAgIHBhZGRpbmdUb3A6IFwiMTBweFwiLFxyXG4gICAgICAgIHBhZGRpbmdCb3R0b206IFwiMTBweFwiLFxyXG4gICAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXHJcbiAgICAgICAgb3ZlcmZsb3dYOiBcImhpZGRlblwiXHJcbiAgICAgIH19XHJcbiAgICAgIHJvbGU9XCJwcmVzZW50YXRpb25cIlxyXG4gICAgICBvbkNsaWNrPXt0b2dnbGVEcmF3ZXIoZmFsc2UpfVxyXG4gICAgICBvbktleURvd249e3RvZ2dsZURyYXdlcihmYWxzZSl9XHJcbiAgICA+XHJcbiAgICAgIDxMaXN0PlxyXG4gICAgICAgIDxMaXN0SXRlbT5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCIgc3R5bGU9e3sgdGV4dERlY29yYXRpb246IFwibm9uZVwiLCBjb2xvcjogXCJpbmhlcml0XCIgfX0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkhvbWVcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvTGlzdEl0ZW0+XHJcbiAgICAgICAgPExpc3RJdGVtPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgaHJlZj1cIi9hYm91dFwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkFib3V0XCIgLz5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgIDxMaXN0SXRlbT5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIGhyZWY9XCIvY21zL2FsbC1wcm9kdWN0c1wiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIlByb2R1Y3RzXCIgLz5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgIDxMaXN0SXRlbT5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIGhyZWY9XCIvY29udGFjdFwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkNvbnRhY3RcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvTGlzdEl0ZW0+XHJcbiAgICAgICAgPExpc3RJdGVtPlxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9hdXRoL2xvZ2luXCIgc3R5bGU9e3sgdGV4dERlY29yYXRpb246IFwibm9uZVwiLCBjb2xvcjogXCJpbmhlcml0XCIgfX0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkxvZ0luXCIgLz5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICA8L0xpc3Q+XHJcbiAgICA8L0JveD5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPEFwcEJhciBwb3NpdGlvbj1cInN0YXRpY1wiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCIjNWI2MzZhXCIgfX0+XHJcbiAgICAgICAgPFRvb2xiYXI+XHJcbiAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICBlZGdlPVwic3RhcnRcIlxyXG4gICAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwibG9nb1wiXHJcbiAgICAgICAgICAgIHN4PXt7IGRpc3BsYXk6IHsgeHM6IFwibm9uZVwiLCBtZDogXCJmbGV4XCIgfSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8TG9jYWxMaWJyYXJ5SWNvbiAvPlxyXG4gICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgdmFyaWFudD1cImg2XCJcclxuICAgICAgICAgICAgY29tcG9uZW50PVwiZGl2XCJcclxuICAgICAgICAgICAgc3g9e3sgZmxleEdyb3c6IDEsIGRpc3BsYXk6IHsgeHM6IFwibm9uZVwiLCBtZDogXCJmbGV4XCIgfSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBGcm9udEVuZCBQYXRoU2FsYVxyXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiB7IHhzOiBcIm5vbmVcIiwgbWQ6IFwiZmxleFwiIH0gfX0+XHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgaHJlZj1cIi9cIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPkhvbWU8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgIGhyZWY9XCIvYWJvdXRcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPkFib3V0PC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICBocmVmPVwiL2Ntcy9hbGwtcHJvZHVjdHNcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPlByb2R1Y3RzPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICBocmVmPVwiL2NvbnRhY3RcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiwgY29sb3I6IFwiaW5oZXJpdFwiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPkNvbnRhY3Q8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2F1dGgvbG9naW5cIiBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsIGNvbG9yOiBcImluaGVyaXRcIiB9fT5cclxuICAgICAgICAgICAgICA8QnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPkxvZ0luPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgPEJveCBzeD17eyBkaXNwbGF5OiB7IHhzOiBcImZsZXhcIiwgbWQ6IFwibm9uZVwiIH0gfX0+XHJcbiAgICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICBlZGdlPVwic3RhcnRcIlxyXG4gICAgICAgICAgICAgIGNvbG9yPVwiaW5oZXJpdFwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlRHJhd2VyKHRydWUpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPE1lbnVJY29uIC8+XHJcbiAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICAgIGFuY2hvcj1cInRvcFwiXHJcbiAgICAgICAgICAgICAgb3Blbj17aXNEcmF3ZXJPcGVufVxyXG4gICAgICAgICAgICAgIG9uQ2xvc2U9e3RvZ2dsZURyYXdlcihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgUGFwZXJQcm9wcz17e1xyXG4gICAgICAgICAgICAgICAgc3g6IHtcclxuICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwdndcIixcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLFxyXG4gICAgICAgICAgICAgICAgICBvdmVyZmxvd1g6IFwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2RyYXdlckxpc3R9XHJcbiAgICAgICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICBlZGdlPVwic3RhcnRcIlxyXG4gICAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwibG9nb1wiXHJcbiAgICAgICAgICAgIHN4PXt7IGRpc3BsYXk6IHsgeHM6IFwiZmxleFwiLCBtZDogXCJub25lXCIgfSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8TG9jYWxMaWJyYXJ5SWNvbiAvPlxyXG4gICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgdmFyaWFudD1cImg2XCJcclxuICAgICAgICAgICAgY29tcG9uZW50PVwiZGl2XCJcclxuICAgICAgICAgICAgc3g9e3sgZmxleEdyb3c6IDEsIGRpc3BsYXk6IHsgeHM6IFwiZmxleFwiLCBtZDogXCJub25lXCIgfSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBGcm9udEVuZCBQYXRoU2FsYVxyXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDwvVG9vbGJhcj5cclxuICAgICAgPC9BcHBCYXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyOyJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiQXBwQmFyIiwiQm94IiwiQnV0dG9uIiwiSWNvbkJ1dHRvbiIsIlRvb2xiYXIiLCJUeXBvZ3JhcGh5IiwiRHJhd2VyIiwiTGlzdCIsIkxpc3RJdGVtIiwiTGlzdEl0ZW1UZXh0IiwiTG9jYWxMaWJyYXJ5SWNvbiIsIk1lbnVJY29uIiwiTGluayIsIkhlYWRlciIsImlzRHJhd2VyT3BlbiIsInNldElzRHJhd2VyT3BlbiIsInRvZ2dsZURyYXdlciIsIm9wZW4iLCJldmVudCIsInR5cGUiLCJrZXkiLCJkcmF3ZXJMaXN0Iiwic3giLCJ3aWR0aCIsIm1heFdpZHRoIiwicGFkZGluZ1RvcCIsInBhZGRpbmdCb3R0b20iLCJib3hTaXppbmciLCJvdmVyZmxvd1giLCJyb2xlIiwib25DbGljayIsIm9uS2V5RG93biIsImhyZWYiLCJzdHlsZSIsInRleHREZWNvcmF0aW9uIiwiY29sb3IiLCJwcmltYXJ5IiwiZGl2IiwicG9zaXRpb24iLCJiYWNrZ3JvdW5kQ29sb3IiLCJzaXplIiwiZWRnZSIsImFyaWEtbGFiZWwiLCJkaXNwbGF5IiwieHMiLCJtZCIsInZhcmlhbnQiLCJjb21wb25lbnQiLCJmbGV4R3JvdyIsImFuY2hvciIsIm9uQ2xvc2UiLCJQYXBlclByb3BzIiwibWFyZ2luIiwicGFkZGluZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./layout/header/index.tsx\n");

/***/ }),

/***/ "./layout/wrapper/wrapper.tsx":
/*!************************************!*\
  !*** ./layout/wrapper/wrapper.tsx ***!
  \************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../header */ \"./layout/header/index.tsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../footer */ \"./layout/footer/index.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_2__, _footer__WEBPACK_IMPORTED_MODULE_3__]);\n([_header__WEBPACK_IMPORTED_MODULE_2__, _footer__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\nconst Wrapper = ({ children })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\wrapper\\\\wrapper.tsx\",\n                lineNumber: 13,\n                columnNumber: 9\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\wrapper\\\\wrapper.tsx\",\n                lineNumber: 14,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\layout\\\\wrapper\\\\wrapper.tsx\",\n                lineNumber: 15,\n                columnNumber: 9\n            }, undefined)\n        ]\n    }, void 0, true);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wrapper);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvd3JhcHBlci93cmFwcGVyLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUF3QztBQUNUO0FBQ0E7QUFPL0IsTUFBTUcsVUFBVSxDQUFDLEVBQUVDLFFBQVEsRUFBZTtJQUN4QyxxQkFDRTs7MEJBQ0ksOERBQUNILCtDQUFNQTs7Ozs7MEJBQ0gsOERBQUNJOzBCQUFNRDs7Ozs7OzBCQUNYLDhEQUFDRiwrQ0FBTUE7Ozs7Ozs7QUFHZjtBQUVBLGlFQUFlQyxPQUFPQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1qcy1maXJzdC1leGFtLy4vbGF5b3V0L3dyYXBwZXIvd3JhcHBlci50c3g/Yjg3NyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnLi4vaGVhZGVyJztcclxuaW1wb3J0IEZvb3RlciBmcm9tICcuLi9mb290ZXInO1xyXG5cclxuXHJcbmludGVyZmFjZSBMYXlvdXRQcm9wcyB7XHJcbiAgICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG59XHJcblxyXG5jb25zdCBXcmFwcGVyID0gKHsgY2hpbGRyZW4gfTogTGF5b3V0UHJvcHMpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgICA8SGVhZGVyIC8+XHJcbiAgICAgICAgICAgIDxtYWluPntjaGlsZHJlbn08L21haW4+XHJcbiAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBXcmFwcGVyIl0sIm5hbWVzIjpbIlJlYWN0IiwiSGVhZGVyIiwiRm9vdGVyIiwiV3JhcHBlciIsImNoaWxkcmVuIiwibWFpbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./layout/wrapper/wrapper.tsx\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _layout_wrapper_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/layout/wrapper/wrapper */ \"./layout/wrapper/wrapper.tsx\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @tanstack/react-query */ \"@tanstack/react-query\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_wrapper_wrapper__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__]);\n([_layout_wrapper_wrapper__WEBPACK_IMPORTED_MODULE_1__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\nfunction App({ Component, pageProps }) {\n    const queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClient();\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClientProvider, {\n        client: queryClient,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_layout_wrapper_wrapper__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_app.tsx\",\n                lineNumber: 12,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_app.tsx\",\n            lineNumber: 11,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_app.tsx\",\n        lineNumber: 10,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUErQztBQUNqQjtBQUMyQztBQUcxRCxTQUFTRyxJQUFJLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFZO0lBQzVELE1BQU1DLGNBQWMsSUFBSUwsOERBQVdBO0lBRW5DLHFCQUNFLDhEQUFDQyxzRUFBbUJBO1FBQUNLLFFBQVFEO2tCQUMzQiw0RUFBQ04sK0RBQU9BO3NCQUNOLDRFQUFDSTtnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7O0FBSWhDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1qcy1maXJzdC1leGFtLy4vcGFnZXMvX2FwcC50c3g/MmZiZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgV3JhcHBlciBmcm9tIFwiQC9sYXlvdXQvd3JhcHBlci93cmFwcGVyXCI7XG5pbXBvcnQgXCJAL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSBcIm5leHQvYXBwXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KCk7XG5cbiAgcmV0dXJuIChcbiAgICA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT5cbiAgICAgIDxXcmFwcGVyPlxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICA8L1dyYXBwZXI+XG4gICAgPC9RdWVyeUNsaWVudFByb3ZpZGVyPlxuKTtcbn1cbiJdLCJuYW1lcyI6WyJXcmFwcGVyIiwiUXVlcnlDbGllbnQiLCJRdWVyeUNsaWVudFByb3ZpZGVyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwicXVlcnlDbGllbnQiLCJjbGllbnQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./pages/_document.tsx":
/*!*****************************!*\
  !*** ./pages/_document.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_document.tsx\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_document.tsx\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_document.tsx\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_document.tsx\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Agnibrata Shee\\\\Desktop\\\\nextJs\\\\next-js-first-exam\\\\pages\\\\_document.tsx\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQudHN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE2RDtBQUU5QyxTQUFTSTtJQUN0QixxQkFDRSw4REFBQ0osK0NBQUlBO1FBQUNLLE1BQUs7OzBCQUNULDhEQUFDSiwrQ0FBSUE7Ozs7OzBCQUNMLDhEQUFDSzs7a0NBQ0MsOERBQUNKLCtDQUFJQTs7Ozs7a0NBQ0wsOERBQUNDLHFEQUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJbkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWpzLWZpcnN0LWV4YW0vLi9wYWdlcy9fZG9jdW1lbnQudHN4P2QzN2QiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSHRtbCwgSGVhZCwgTWFpbiwgTmV4dFNjcmlwdCB9IGZyb20gXCJuZXh0L2RvY3VtZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERvY3VtZW50KCkge1xuICByZXR1cm4gKFxuICAgIDxIdG1sIGxhbmc9XCJlblwiPlxuICAgICAgPEhlYWQgLz5cbiAgICAgIDxib2R5PlxuICAgICAgICA8TWFpbiAvPlxuICAgICAgICA8TmV4dFNjcmlwdCAvPlxuICAgICAgPC9ib2R5PlxuICAgIDwvSHRtbD5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJIdG1sIiwiSGVhZCIsIk1haW4iLCJOZXh0U2NyaXB0IiwiRG9jdW1lbnQiLCJsYW5nIiwiYm9keSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_document.tsx\n");

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\n\n\nfunction Home() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: \"Hello Home\"\n    }, void 0, false);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUtNQTtBQUtBQztBQU1TLFNBQVNDO0lBQ3RCLHFCQUNFO2tCQUFFOztBQUlOIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1qcy1maXJzdC1leGFtLy4vcGFnZXMvaW5kZXgudHN4PzA3ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IEltYWdlIGZyb20gXCJuZXh0L2ltYWdlXCI7XG5pbXBvcnQgbG9jYWxGb250IGZyb20gXCJuZXh0L2ZvbnQvbG9jYWxcIjtcbmltcG9ydCBzdHlsZXMgZnJvbSBcIkAvc3R5bGVzL0hvbWUubW9kdWxlLmNzc1wiO1xuXG5jb25zdCBnZWlzdFNhbnMgPSBsb2NhbEZvbnQoe1xuICBzcmM6IFwiLi9mb250cy9HZWlzdFZGLndvZmZcIixcbiAgdmFyaWFibGU6IFwiLS1mb250LWdlaXN0LXNhbnNcIixcbiAgd2VpZ2h0OiBcIjEwMCA5MDBcIixcbn0pO1xuY29uc3QgZ2Vpc3RNb25vID0gbG9jYWxGb250KHtcbiAgc3JjOiBcIi4vZm9udHMvR2Vpc3RNb25vVkYud29mZlwiLFxuICB2YXJpYWJsZTogXCItLWZvbnQtZ2Vpc3QtbW9ub1wiLFxuICB3ZWlnaHQ6IFwiMTAwIDkwMFwiLFxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIEhlbGxvIEhvbWVcbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJnZWlzdFNhbnMiLCJnZWlzdE1vbm8iLCJIb21lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@mui/icons-material/LocalLibrary":
/*!***************************************************!*\
  !*** external "@mui/icons-material/LocalLibrary" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocalLibrary");

/***/ }),

/***/ "@mui/icons-material/Menu":
/*!*******************************************!*\
  !*** external "@mui/icons-material/Menu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ "@mui/material/utils":
/*!**************************************!*\
  !*** external "@mui/material/utils" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/utils");

/***/ }),

/***/ "@mui/system":
/*!******************************!*\
  !*** external "@mui/system" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ "@mui/system/DefaultPropsProvider":
/*!***************************************************!*\
  !*** external "@mui/system/DefaultPropsProvider" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/DefaultPropsProvider");

/***/ }),

/***/ "@mui/system/InitColorSchemeScript":
/*!****************************************************!*\
  !*** external "@mui/system/InitColorSchemeScript" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/InitColorSchemeScript");

/***/ }),

/***/ "@mui/system/RtlProvider":
/*!******************************************!*\
  !*** external "@mui/system/RtlProvider" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/RtlProvider");

/***/ }),

/***/ "@mui/system/colorManipulator":
/*!***********************************************!*\
  !*** external "@mui/system/colorManipulator" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/colorManipulator");

/***/ }),

/***/ "@mui/system/createBreakpoints":
/*!************************************************!*\
  !*** external "@mui/system/createBreakpoints" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createBreakpoints");

/***/ }),

/***/ "@mui/system/createStyled":
/*!*******************************************!*\
  !*** external "@mui/system/createStyled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createStyled");

/***/ }),

/***/ "@mui/system/createTheme":
/*!******************************************!*\
  !*** external "@mui/system/createTheme" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createTheme");

/***/ }),

/***/ "@mui/system/cssVars":
/*!**************************************!*\
  !*** external "@mui/system/cssVars" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/cssVars");

/***/ }),

/***/ "@mui/system/spacing":
/*!**************************************!*\
  !*** external "@mui/system/spacing" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/spacing");

/***/ }),

/***/ "@mui/system/styleFunctionSx":
/*!**********************************************!*\
  !*** external "@mui/system/styleFunctionSx" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/styleFunctionSx");

/***/ }),

/***/ "@mui/system/useThemeProps":
/*!********************************************!*\
  !*** external "@mui/system/useThemeProps" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/useThemeProps");

/***/ }),

/***/ "@mui/utils":
/*!*****************************!*\
  !*** external "@mui/utils" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils");

/***/ }),

/***/ "@mui/utils/HTMLElementType":
/*!*********************************************!*\
  !*** external "@mui/utils/HTMLElementType" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/HTMLElementType");

/***/ }),

/***/ "@mui/utils/appendOwnerState":
/*!**********************************************!*\
  !*** external "@mui/utils/appendOwnerState" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/appendOwnerState");

/***/ }),

/***/ "@mui/utils/capitalize":
/*!****************************************!*\
  !*** external "@mui/utils/capitalize" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/capitalize");

/***/ }),

/***/ "@mui/utils/chainPropTypes":
/*!********************************************!*\
  !*** external "@mui/utils/chainPropTypes" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/chainPropTypes");

/***/ }),

/***/ "@mui/utils/composeClasses":
/*!********************************************!*\
  !*** external "@mui/utils/composeClasses" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/composeClasses");

/***/ }),

/***/ "@mui/utils/createChainedFunction":
/*!***************************************************!*\
  !*** external "@mui/utils/createChainedFunction" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/createChainedFunction");

/***/ }),

/***/ "@mui/utils/debounce":
/*!**************************************!*\
  !*** external "@mui/utils/debounce" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/debounce");

/***/ }),

/***/ "@mui/utils/deepmerge":
/*!***************************************!*\
  !*** external "@mui/utils/deepmerge" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deepmerge");

/***/ }),

/***/ "@mui/utils/deprecatedPropType":
/*!************************************************!*\
  !*** external "@mui/utils/deprecatedPropType" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deprecatedPropType");

/***/ }),

/***/ "@mui/utils/elementAcceptingRef":
/*!*************************************************!*\
  !*** external "@mui/utils/elementAcceptingRef" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementAcceptingRef");

/***/ }),

/***/ "@mui/utils/elementTypeAcceptingRef":
/*!*****************************************************!*\
  !*** external "@mui/utils/elementTypeAcceptingRef" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementTypeAcceptingRef");

/***/ }),

/***/ "@mui/utils/extractEventHandlers":
/*!**************************************************!*\
  !*** external "@mui/utils/extractEventHandlers" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/extractEventHandlers");

/***/ }),

/***/ "@mui/utils/formatMuiErrorMessage":
/*!***************************************************!*\
  !*** external "@mui/utils/formatMuiErrorMessage" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/formatMuiErrorMessage");

/***/ }),

/***/ "@mui/utils/generateUtilityClass":
/*!**************************************************!*\
  !*** external "@mui/utils/generateUtilityClass" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClass");

/***/ }),

/***/ "@mui/utils/generateUtilityClasses":
/*!****************************************************!*\
  !*** external "@mui/utils/generateUtilityClasses" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClasses");

/***/ }),

/***/ "@mui/utils/getReactElementRef":
/*!************************************************!*\
  !*** external "@mui/utils/getReactElementRef" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/getReactElementRef");

/***/ }),

/***/ "@mui/utils/integerPropType":
/*!*********************************************!*\
  !*** external "@mui/utils/integerPropType" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/integerPropType");

/***/ }),

/***/ "@mui/utils/isFocusVisible":
/*!********************************************!*\
  !*** external "@mui/utils/isFocusVisible" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/isFocusVisible");

/***/ }),

/***/ "@mui/utils/isMuiElement":
/*!******************************************!*\
  !*** external "@mui/utils/isMuiElement" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/isMuiElement");

/***/ }),

/***/ "@mui/utils/mergeSlotProps":
/*!********************************************!*\
  !*** external "@mui/utils/mergeSlotProps" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/mergeSlotProps");

/***/ }),

/***/ "@mui/utils/ownerDocument":
/*!*******************************************!*\
  !*** external "@mui/utils/ownerDocument" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/ownerDocument");

/***/ }),

/***/ "@mui/utils/ownerWindow":
/*!*****************************************!*\
  !*** external "@mui/utils/ownerWindow" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/ownerWindow");

/***/ }),

/***/ "@mui/utils/refType":
/*!*************************************!*\
  !*** external "@mui/utils/refType" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/refType");

/***/ }),

/***/ "@mui/utils/requirePropFactory":
/*!************************************************!*\
  !*** external "@mui/utils/requirePropFactory" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/requirePropFactory");

/***/ }),

/***/ "@mui/utils/resolveComponentProps":
/*!***************************************************!*\
  !*** external "@mui/utils/resolveComponentProps" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/resolveComponentProps");

/***/ }),

/***/ "@mui/utils/resolveProps":
/*!******************************************!*\
  !*** external "@mui/utils/resolveProps" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/resolveProps");

/***/ }),

/***/ "@mui/utils/setRef":
/*!************************************!*\
  !*** external "@mui/utils/setRef" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/setRef");

/***/ }),

/***/ "@mui/utils/unsupportedProp":
/*!*********************************************!*\
  !*** external "@mui/utils/unsupportedProp" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/unsupportedProp");

/***/ }),

/***/ "@mui/utils/useControlled":
/*!*******************************************!*\
  !*** external "@mui/utils/useControlled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useControlled");

/***/ }),

/***/ "@mui/utils/useEnhancedEffect":
/*!***********************************************!*\
  !*** external "@mui/utils/useEnhancedEffect" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEnhancedEffect");

/***/ }),

/***/ "@mui/utils/useEventCallback":
/*!**********************************************!*\
  !*** external "@mui/utils/useEventCallback" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEventCallback");

/***/ }),

/***/ "@mui/utils/useForkRef":
/*!****************************************!*\
  !*** external "@mui/utils/useForkRef" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useForkRef");

/***/ }),

/***/ "@mui/utils/useId":
/*!***********************************!*\
  !*** external "@mui/utils/useId" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useId");

/***/ }),

/***/ "@mui/utils/useLazyRef":
/*!****************************************!*\
  !*** external "@mui/utils/useLazyRef" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useLazyRef");

/***/ }),

/***/ "@mui/utils/useTimeout":
/*!****************************************!*\
  !*** external "@mui/utils/useTimeout" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useTimeout");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group":
/*!*****************************************!*\
  !*** external "react-transition-group" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "@tanstack/react-query":
/*!****************************************!*\
  !*** external "@tanstack/react-query" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = import("clsx");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/@mui"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F&preferredRegion=&absolutePagePath=.%2Fpages%5Cindex.tsx&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();